--
-- Fichier généré par SQLiteStudio v3.4.4 sur Zom Feb 23 21:37:17 2024
--
-- Encodage texte utilisé : UTF-8
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tableau : bibliotheque
DROP TABLE IF EXISTS bibliotheque;
CREATE TABLE IF NOT EXISTS bibliotheque (nom_auteur TEXT NOT NULL, id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, nom_livre TEXT UNIQUE NOT NULL);
INSERT INTO bibliotheque (nom_auteur, id, nom_livre) VALUES ('Tom cruier', 1, 'Fete tenebreux');
INSERT INTO bibliotheque (nom_auteur, id, nom_livre) VALUES ('victor hugo', 2, 'les miserables');
INSERT INTO bibliotheque (nom_auteur, id, nom_livre) VALUES ('disney', 4, 'blanche neige et les sept nains');
INSERT INTO bibliotheque (nom_auteur, id, nom_livre) VALUES ('thomas shlesser', 6, 'les yeux de mona');
INSERT INTO bibliotheque (nom_auteur, id, nom_livre) VALUES ('turtleme', 7, 'the beginning after the end');
INSERT INTO bibliotheque (nom_auteur, id, nom_livre) VALUES ('eichiro oda', 8, 'one piece');
INSERT INTO bibliotheque (nom_auteur, id, nom_livre) VALUES ('lara croft', 9, 'the last of them');
INSERT INTO bibliotheque (nom_auteur, id, nom_livre) VALUES ('test', 10, 'test');

-- Index : sqlite_autoindex_bibliotheque_1
DROP INDEX IF EXISTS sqlite_autoindex_bibliotheque_1;
CREATE UNIQUE INDEX IF NOT EXISTS sqlite_autoindex_bibliotheque_1 ON bibliotheque (id COLLATE BINARY);

-- Index : sqlite_autoindex_bibliotheque_2
DROP INDEX IF EXISTS sqlite_autoindex_bibliotheque_2;
CREATE UNIQUE INDEX IF NOT EXISTS sqlite_autoindex_bibliotheque_2 ON bibliotheque (nom_livre COLLATE BINARY);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
