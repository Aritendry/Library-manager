import sqlite3
connexion_db=sqlite3.connect("gestionnaire_de_bibliotheque.db")
curseur=connexion_db.cursor()
if connexion_db:
    print("La connexion est reussi")
else:
    print("Erreur de connexion")
def s():
        print("--------------------------------------------------------")
def f():
        print("************************************************************************")
        print("************************************************************************")
def add():
    f()
    name = str(input("Entrez le titre du livre : ")).lower()
    auteur = str(input("Entrez le nom de l'auteur : ")).lower()
        
    curseur.execute("INSERT INTO bibliotheque (nom_livre, nom_auteur) VALUES (?, ?)", (name, auteur))
    connexion_db.commit()
    print("Le livre a été ajouté")
    f()
def search():
    f()
    search_livre = str(input("Entrez le livre à rechercher : ")).lower()
    curseur.execute("SELECT nom_livre FROM bibliotheque WHERE nom_livre = ?", (search_livre,))
    resultat = curseur.fetchall()
    if resultat:
        print("Le livre", search_livre, "a été trouvé avec succès")
    else:
        print("Le livre", search_livre, "n'a pas été trouvé")
        print("************************************************************************")
    f()
def afficher():
    curseur.execute("SELECT * FROM bibliotheque")
    resultat=curseur.fetchall()
    if resultat:
        for ligne in resultat:
                print("________________________________________________")
                print("")
                print("Titre du livre :",ligne[0])
                print("")
                print("ID : ",ligne[1])
                print()
                print("Auteur du livre : ",ligne[2])
                print("")
                print("________________________________________________")
        else:
            print("Pas de livres dans votre base de donnée")
def delete():
    afficher()
    f()
    id_delete=str(input("Entrez l'id a supprimer : "))
    curseur.execute("DELETE FROM bibliotheque WHERE id = ?",(id_delete,))
    connexion_db.commit()
    f()
def control():
    while True:
        choix=int(input("Entrez votre choix : "))
        if choix ==1:
            s()
            add()
            s()
        elif choix==2:
            s()
            search()
            s()
        elif choix ==3:
            s()
            afficher()
            s()
        elif choix ==4:
            s()
            delete()
            s()
        elif choix==5:
            s()
            count()
            s()
        elif choix==6:
            s()
            show_book()
            s()
        elif choix==7:
            s()
            update()
            s()
        elif choix ==8:
            s()
            emprunter()
            s()
        else:
            print("Le chiffre que vous avez entrez semble incorrecte")
def count():
     curseur.execute("SELECT COUNT(nom_livre) FROM bibliotheque")
     resultat=curseur.fetchall()
     if resultat:
        print("Il y a :",resultat," article")
     else:
        print("Il 'y a pas de livre")
def show_book():
    choix=int(input(" En alaphabetique 1 ou normale 2 : "))
    if choix ==1:
        curseur.execute("SELECT DISTINCT nom_livre FROM bibliotheque ORDER BY nom_livre ASC")
    resultat=curseur.fetchall()
    if resultat:
        print(resultat ,"\n")
    elif choix==2:
        curseur.execute("SELECT DISTINCT nom_livre FROM bibliotheque ")
    resultat=curseur.fetchall()
    if resultat:
        print(resultat ,"\n")
    else:
        print("Information non prise en compte")
        return 0       
def update():
    id_l=int(input("Entrez l'id du livre a mettre a jour : "))
    new_l=str(input("Entrez le nouveau nom du livre : "))
    new_a=str(input("ENtrez le nouveau nom de l'auteur : "))
    curseur.execute("UPDATE bibliotheque set nom_livre=? ,nom_auteur=? WHERE id=?",(new_l,new_a,id_l))
    connexion_db.commit()
    print()
    print()
    print("Maj terminée avec succes")
def emprunter():
    nom=str(input("Entrez votre nom s'il vous plait : ")).lower()
    id_l=int(input("Entrez l'id du livre : "))
    curseur.execute("SELECT nom_livre FROM bibliotheque WHERE id=?",(id_l,))
    resultat=curseur.fetchone()
    if resultat:
        titre_livre = resultat[0]
        # Vérifier si le livre est déjà emprunté
        curseur.execute("SELECT livre_u FROM utilisateur WHERE livre_u=?", (titre_livre,))
        livre_emprunte = curseur.fetchone()

        if livre_emprunte:
            print("Désolé, ce livre est déjà emprunté par quelqu'un d'autre.")
        else:
            # Mettre à jour la table utilisateur pour enregistrer l'emprunt
            curseur.execute("INSERT INTO utilisateur (nom_u,livre_u) VALUES(?,?)", (nom, titre_livre))
            connexion_db.commit()
            print(f"Le livre '{titre_livre.capitalize()}' a été emprunté avec succès par {nom}.")
  