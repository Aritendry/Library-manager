from fonction import *

print("Gestionnaire de bibliotheque")
print("Voici les choix")
print("1- Ajouter un livre")
print("2- Recherchez un livre")    
print("3- Afficher les livres existantes")
print("4- Supprimer un livre")
print("5- Connaitre le nombre des articles")
print("6- Afficher les livres existantes")
print("7- Mettre a jour un livre en particulier : ")
print("8- Emprunter un livre")
if __name__=="__main__":
    control()