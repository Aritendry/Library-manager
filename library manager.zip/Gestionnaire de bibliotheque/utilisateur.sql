--
-- Fichier généré par SQLiteStudio v3.4.4 sur Zom Feb 23 21:37:38 2024
--
-- Encodage texte utilisé : UTF-8
--
--77777-------------------------------------------------------------------------------------------------
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tableau : utilisateur
DROP TABLE IF EXISTS utilisateur;
CREATE TABLE IF NOT EXISTS utilisateur (nom_u TEXT UNIQUE NOT NULL, id_u INTEGER UNIQUE PRIMARY KEY AUTOINCREMENT, livre_u TEXT);

-- Index : sqlite_autoindex_utilisateur_1
DROP INDEX IF EXISTS sqlite_autoindex_utilisateur_1;
CREATE UNIQUE INDEX IF NOT EXISTS sqlite_autoindex_utilisateur_1 ON utilisateur (nom_u COLLATE BINARY);

-- Index : sqlite_autoindex_utilisateur_2
DROP INDEX IF EXISTS sqlite_autoindex_utilisateur_2;
CREATE UNIQUE INDEX IF NOT EXISTS sqlite_autoindex_utilisateur_2 ON utilisateur (id_u COLLATE BINARY);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
